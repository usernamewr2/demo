<?php

    $connect = new mysqli("192.168.142.50:3306", "demka", "demka_123", "db_demo_2024");

    if($connect->connect_error){
        die ("Ошибка подключения к базе данных");
    }

?>