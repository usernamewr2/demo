<?php
    session_start();
    include "inc/header.php";
?>
<body>

<!-- <div class="container p-3 text-center">
    <h1 class="mt-3 mb-4 text-white display-1"></h1>
    <p class="p-1 pt-4 display-6 text-light">Наш портал представляет собой информационную систему для помощи полиции по своевременной фиксации нарушений правил дорожного движения.</p>
</div>
<div class="container p-2 mb-5 text-center">
    <a href="/auth/" class="btn btn-success text-success-emphasis bg-light w-75 p-3 fs-2 rounded-pill fw-bold shadow-lg">Подать заявление</a>
    <h2 class="display-4 mt-5 text-white">Будь ответственным гражданином!</h2>
</div> -->

<main>
<section class="hero">
            <div class="hero-text">
                <h1>Предварительная запись на ремонт</h1>
                <button>Записаться</button>
            </div>
        </section>

        <section id="services" class="services">
            <h2>Наши услуги</h2>
            <div class="services-grid">
                <div class="service">Тонировка задней полусферы</div>
                <div class="service">Тонировка передней полусферы</div>
                <div class="service">Тонировка боковых зеркал</div>
                <div class="service">Бронирование полного кузова</div>
                <div class="service">Бронирование фар</div>
                <div class="service">Бронирование арок</div>
            </div>
        </section>

        <section id="works" class="works">
            <h2>Примеры наших работ</h2>
            <div class="works-gallery">
                <img src="assets/images/7.jpg" alt="Машина">
            </div>
        </section>
    </main>
<?php
    include "inc/footer.php";
?>

<!-- 
<body class="bg-success"></body>

<main>
        
</main> -->