        <footer class="sticky-bottom bg-dark text-light">
            <div class="container-fluid p-3 pt-3">
                <p>Починим!</p>
            </div>
        </footer>
    </main>
    <script src="/assets/bootstrap/js/bootstrap.bundle.js"></script>

      <script>
           
      (() => {
        'use strict'
  
        const forms = document.querySelectorAll('.needs-validation')

        Array.from(forms).forEach(form => {
          form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }

            form.classList.add('was-validated')
          }, false)
        })
      })()
      </script>
</body>
</html>