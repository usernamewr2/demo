<?php
    $menu = "";
    if(isset($_SESSION['login'])){
        if($_SESSION['role'] == "Администратор"){
            $menu .= '<li class="nav-item">
                        <a class="nav-link" href="/admin/">Админ Панель</a>
                    </li>';
        }
        $menu .= '<li class="nav-item">
                <a class="nav-link" href="/profile/">Личный кабинет</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/admin/controllers/logout.php">Выйти</a>
            </li>';
    }else{
        $menu = '<li class="nav-item">
                <a class="nav-link" href="/auth/">Вход</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/register/">Регистрация</a>
            </li>';
    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Починим!</title>
    <link rel="stylesheet" href="/assets/style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Alumni+Sans:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet" />
</head>
<body>
<main class="text-success-emphasis">
        <header class="bg-success border-bottom border-success-emphasis">
            <div class="container">
                <nav class="navbar navbar-expand-lg w-100 p-3 navbar-dark">
                    <div class="container-fluid">
                        <a class="navbar-brand" href="/">Починим!</a>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <?=$menu?>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
